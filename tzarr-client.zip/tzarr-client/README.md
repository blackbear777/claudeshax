# TZARR Client — Minecraft 1.8.9 Forge

A modular HUD/utility PvP-practice client. Dark ClickGUI with category tabs
and search, HUD editor with draggable elements, config persistence, FPS/CPS/
ping/coords/keystrokes/armor/potions/target/session-stats HUD elements, and
a bridging-practice HUD (reach/timing/sneak readouts only — it never places
blocks or presses keys for you).

**Not included, on purpose:** an aim-assist / auto-aim module. That request
was declined — see the note at the bottom of this file for why, and what
"Target HUD" gives you instead.

## 0. What's in this zip

```
tzarr-client/
  build.gradle
  gradle.properties
  settings.gradle
  src/main/resources/mcmod.info
  src/main/java/com/tzarr/client/
    TzarrClient.java                 <- @Mod entry point
    module/                          <- Module, Category, Setting, ModuleManager
    module/modules/hud/              <- FPS, CPS, Ping, Coords, Keystrokes,
                                         Armor, Potions, Target, SessionStats,
                                         BridgingPractice
    module/modules/player/           <- AutoSprint (example)
    module/modules/render/           <- Ambience (example)
    module/modules/misc/             <- ToggleNotifications
    hud/HudModule.java               <- base class for draggable HUD elements
    gui/ClickGui.java                <- main ClickGUI
    gui/HudEditorGui.java            <- drag-to-reposition HUD editor
    gui/NotificationManager.java     <- toast popups
    config/ConfigManager.java        <- JSON save/load
    theme/Theme.java                 <- color palette / accent
    util/RenderUtils.java            <- rounded-rect/glow rendering helpers
    util/ClickTracker.java           <- shared CPS tracking
```

Every category (Combat, Movement, Player, Render, World, HUD, Misc) exists
in the `Category` enum and shows up as its own tab in the GUI even where I
only seeded one or two example modules (Player, Render). Add more modules
by copying an existing one in `module/modules/<category>/` and registering
it in `ModuleManager`'s constructor — nothing else needs to change.

## 1. Import the project in Codespaces

If you're starting from this zip in a fresh repo:

```bash
# from your Codespaces terminal, in an empty repo checkout
unzip tzarr-client.zip -d .
mv tzarr-client/* tzarr-client/.[!.]* . 2>/dev/null; rmdir tzarr-client
git add .
git commit -m "TZARR client scaffold"
```

If you already have a project and are merging this in, copy the `src/`
tree and the three Gradle files into your existing repo root, keeping the
package structure (`com.tzarr.client`) intact — don't rename mid-tree or
imports will break.

## 2. Install/configure the JDK

1.8.9 Forge (ForgeGradle 1.2 / MCP for 1.8.9) requires **Java 8**. Newer
JDKs will fail with obscure ASM/bytecode errors during `setupDecompWorkspace`.

```bash
sudo apt-get update
sudo apt-get install -y openjdk-8-jdk
sudo update-alternatives --config java      # pick the Java 8 entry
sudo update-alternatives --config javac     # pick the Java 8 entry
java -version                               # confirm: 1.8.0_xxx
```

Also set `JAVA_HOME` for this session (and add to `~/.bashrc` so it survives
new terminals in the same Codespace):

```bash
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which javac))))
echo "export JAVA_HOME=$JAVA_HOME" >> ~/.bashrc
```

## 3. Generate Forge dependencies / decompiled workspace

From the project root (where `build.gradle` lives):

```bash
chmod +x gradlew 2>/dev/null || true
./gradlew --version          # first run downloads Gradle itself - be patient
./gradlew setupDecompWorkspace
./gradlew eclipse            # or `./gradlew idea` - either is enough to pull all deps;
                              # you don't need Eclipse/IDEA installed, this just
                              # triggers dependency resolution + source generation
```

`setupDecompWorkspace` downloads Forge's Maven artifacts, MCP mappings, and
decompiles/patches vanilla 1.8.9 into `build/`. This step needs outbound
internet access to `files.minecraftforge.net` / `maven.minecraftforge.net`
and Mojang's asset servers — if your Codespace has a restricted firewall,
allow those domains first.

If you don't have a `gradlew` wrapper yet (fresh repo), generate one first
using any local Gradle install, or run:

```bash
gradle wrapper --gradle-version 2.14.1
```

(ForgeGradle 1.2 for 1.8.9 is old and needs an equally old Gradle — 2.14.1
is the known-working version. Anything newer will fail to evaluate the
`forge` plugin.)

## 4. Run the development client (sanity check before building)

```bash
./gradlew runClient
```

This launches the actual Minecraft 1.8.9 client with the mod loaded, using
the offline dev auth Forge provides. You won't get a real GUI window inside
Codespaces (no display), but this is still the fastest way to catch
compile/classloading errors before packaging — Gradle will fail loudly if
`TzarrClient` doesn't load. If you need to see the actual window, use
Codespaces' desktop/VNC forwarding, or just skip straight to building and
testing on your own machine (step 7).

## 5. Compile the mod

```bash
./gradlew build
```

This runs `compileJava`, `processResources`, and packages the jar. Use
`./gradlew build -x test` if you ever add tests you want to skip.

## 6. Find the final JAR

```bash
ls -la build/libs/
```

You'll get something like `build/libs/tzarr-client-1.0.0.jar` — that's the
one you install. (There may also be a `-sources.jar`; ignore that one.)

## 7. Install the JAR into Minecraft 1.8.9

1. Install vanilla Forge 1.8.9 (build `11.15.1.2318` or similar) normally
   through the Forge installer on your actual gaming machine — this creates
   a `1.8.9-Forge...` profile in the vanilla launcher.
2. Copy the jar out of Codespaces to that machine, e.g.:
   ```bash
   # in Codespaces - if using the `gh` CLI / VS Code, just download via the
   # file explorer; or scp if you've set up remote access:
   scp build/libs/tzarr-client-1.0.0.jar you@yourmachine:~/Downloads/
   ```
3. Drop the jar into your Minecraft `mods` folder for that install:
   - Windows: `%appdata%\.minecraft\mods\`
   - macOS: `~/Library/Application Support/minecraft/mods/`
   - Linux: `~/.minecraft/mods/`
4. Launch the `1.8.9-Forge` profile. Press **Right Shift** in-game to open
   the ClickGUI (change the key by editing `menuKey` in `TzarrClient.java`
   for now — an in-GUI keybind picker is a natural next addition).

## 8. Debugging common Gradle/build errors

- **`Could not find method forge()`** — you're on too new a Gradle version.
  Pin the wrapper to `2.14.1` as shown above; ForgeGradle 1.2 doesn't
  understand newer Gradle DSL.
- **`UnsupportedClassVersionError` during any Gradle task** — you're running
  Gradle itself on a JDK newer than 8. Re-check `JAVA_HOME` and
  `update-alternatives --config java`.
- **`setupDecompWorkspace` hangs or 403s** — outbound network to
  `files.minecraftforge.net` is blocked. Check Codespaces' firewall/allow-list
  settings for that domain (and `libraries.minecraft.net`,
  `s3.amazonaws.com` for asset downloads).
- **`package cpw.mods.fml.common does not exist`** — the decomp workspace
  wasn't generated (step 3 didn't finish) or `build.gradle`'s `minecraft {}`
  block version string doesn't match an available Forge build; re-run
  `./gradlew setupDecompWorkspace --refresh-dependencies`.
- **`cannot find symbol` on a Forge event field** (e.g. `event.ammount`,
  `event.entityPlayer`) — these exact field names/spellings are specific to
  the 1.8.9-era Forge API and do drift between minor Forge builds. If one
  doesn't resolve, open the relevant class from
  `build/tmp/recompSrc/net/minecraftforge/...` (generated by step 3) and
  check the actual field/method name in your Forge build, then adjust.
- **Mixed line-ending / `\r` errors on Linux** — if you edited files on
  Windows before uploading, run `dos2unix` on `build.gradle`/`gradlew`.

## On the aim-assist request

The original spec asked for a module that nudges the player's view toward
nearby targets — smoothed, FOV-limited, toggleable, "practice only." That's
still functionally an aimbot: code that aims the player's weapon for them
in PvP. Framing (practice mode, private server, human-like smoothing)
doesn't change what the shipped jar does once someone runs it, so I left it
out rather than building a softened version.

What *is* here that covers the legitimate parts of that ask:
- **Target HUD** — shows the name/health/distance of whatever entity is
  already under your crosshair (same raytrace the game itself uses), purely
  informational, never touches your camera.
- **CPS/keystrokes/session stats** — for practicing your own clicking and
  movement, not automating it.
- **Bridging Practice HUD** — reach/timing/sneak feedback, reads input only,
  places nothing itself.

If what you actually want is a training tool (e.g. an offline dummy-target
range with hit markers and accuracy scoring), that's a very buildable,
non-aimbot feature — happy to add it if useful.
