package com.tzarr.client;

import com.tzarr.client.config.ConfigManager;
import com.tzarr.client.gui.ClickGui;
import com.tzarr.client.gui.NotificationManager;
import com.tzarr.client.module.ModuleManager;
import com.tzarr.client.util.ClickTracker;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.InputEvent;
import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.input.Keyboard;

@Mod(modid = "tzarrclient", name = "TZARR Client", version = "1.0.0", clientSideOnly = true)
public class TzarrClient {

    @Mod.Instance("tzarrclient")
    public static TzarrClient instance;

    public static TzarrClient getInstance() {
        return instance;
    }

    private final Minecraft mc = Minecraft.getMinecraft();

    private ModuleManager moduleManager;
    private ConfigManager configManager;
    private NotificationManager notificationManager;
    private ClickTracker clickTracker;

    /** Configurable menu-open key, changeable from the ClickGUI itself in a future pass. */
    private int menuKey = Keyboard.KEY_RSHIFT;

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // Managers that others depend on must exist before ModuleManager builds modules,
        // since several modules call TzarrClient.getInstance() from their constructors.
        instance = this;
        notificationManager = new NotificationManager();
        clickTracker = new ClickTracker();
        configManager = new ConfigManager();
        moduleManager = new ModuleManager();
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
        MinecraftForge.EVENT_BUS.register(moduleManager);
        MinecraftForge.EVENT_BUS.register(clickTracker);
        configManager.load();
    }

    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        if (Keyboard.getEventKey() == menuKey && Keyboard.getEventKeyState() && mc.currentScreen == null) {
            mc.displayGuiScreen(new ClickGui());
        }
    }

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        notificationManager.render();
    }

    public ModuleManager getModuleManager() {
        return moduleManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public NotificationManager getNotificationManager() {
        return notificationManager;
    }

    public ClickTracker getClickTracker() {
        return clickTracker;
    }

    public int getMenuKey() {
        return menuKey;
    }

    public void setMenuKey(int menuKey) {
        this.menuKey = menuKey;
    }
}
