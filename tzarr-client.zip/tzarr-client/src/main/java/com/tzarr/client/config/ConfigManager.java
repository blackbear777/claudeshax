package com.tzarr.client.config;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.tzarr.client.TzarrClient;
import com.tzarr.client.module.Module;
import com.tzarr.client.module.Setting;
import com.tzarr.client.theme.Theme;
import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * Reads/writes {@code .minecraft/config/tzarrclient.json}.
 *
 * Everything the client needs to remember between sessions lives in one
 * file: module enabled-states, keybinds, per-module settings, HUD element
 * positions, and the accent color. Gson ships on Minecraft's own classpath
 * (net.minecraft.launchwrapper depends on it) so no extra jar is needed.
 */
public class ConfigManager {

    private final File configFile;
    private final Map<String, int[]> hudPositions = new HashMap<>(); // name -> [x, y]

    public ConfigManager() {
        File configDir = new File(Minecraft.getMinecraft().mcDataDir, "config");
        if (!configDir.exists()) configDir.mkdirs();
        this.configFile = new File(configDir, "tzarrclient.json");
    }

    public void setHudPosition(String name, int x, int y) {
        hudPositions.put(name, new int[]{x, y});
    }

    /** Returns null if no saved position exists yet - caller should fall back to a default. */
    public int[] getHudPosition(String name) {
        return hudPositions.get(name);
    }

    public void save() {
        JsonObject root = new JsonObject();
        root.addProperty("accentColor", Theme.ACCENT);
        root.addProperty("notificationsEnabled", TzarrClient.getInstance().getNotificationManager().isEnabled());

        JsonArray modulesJson = new JsonArray();
        for (Module m : TzarrClient.getInstance().getModuleManager().getModules()) {
            JsonObject mj = new JsonObject();
            mj.addProperty("name", m.getName());
            mj.addProperty("enabled", m.isEnabled());
            mj.addProperty("keybind", m.getKeyBind());

            JsonObject settingsJson = new JsonObject();
            for (Setting s : m.getSettings()) {
                switch (s.getType()) {
                    case BOOLEAN:
                        settingsJson.addProperty(s.getName(), s.getBool());
                        break;
                    case DOUBLE:
                        settingsJson.addProperty(s.getName(), s.getDouble());
                        break;
                    case MODE:
                        settingsJson.addProperty(s.getName(), s.getModeIndex());
                        break;
                }
            }
            mj.add("settings", settingsJson);
            modulesJson.add(mj);
        }
        root.add("modules", modulesJson);

        JsonObject hudJson = new JsonObject();
        for (Map.Entry<String, int[]> entry : hudPositions.entrySet()) {
            JsonArray pos = new JsonArray();
            pos.add(entry.getValue()[0]);
            pos.add(entry.getValue()[1]);
            hudJson.add(entry.getKey(), pos);
        }
        root.add("hudPositions", hudJson);

        try (FileWriter writer = new FileWriter(configFile)) {
            new GsonBuilder().setPrettyPrinting().create().toJson(root, writer);
        } catch (IOException e) {
            System.err.println("[TZARR] Failed to save config: " + e.getMessage());
        }
    }

    public void load() {
        if (!configFile.exists()) return;

        try (FileReader reader = new FileReader(configFile)) {
            JsonObject root = new JsonParser().parse(reader).getAsJsonObject();

            if (root.has("accentColor")) {
                Theme.setAccent(root.get("accentColor").getAsInt());
            }
            if (root.has("notificationsEnabled")) {
                TzarrClient.getInstance().getNotificationManager().setEnabled(root.get("notificationsEnabled").getAsBoolean());
            }

            if (root.has("modules")) {
                for (JsonElement el : root.getAsJsonArray("modules")) {
                    JsonObject mj = el.getAsJsonObject();
                    String name = mj.get("name").getAsString();
                    Module module = TzarrClient.getInstance().getModuleManager().getModule(name);
                    if (module == null) continue; // config from an older module set - skip safely

                    if (mj.has("keybind")) module.setKeyBind(mj.get("keybind").getAsInt());

                    if (mj.has("settings")) {
                        JsonObject settingsJson = mj.getAsJsonObject("settings");
                        for (Setting s : module.getSettings()) {
                            if (!settingsJson.has(s.getName())) continue;
                            JsonElement value = settingsJson.get(s.getName());
                            switch (s.getType()) {
                                case BOOLEAN:
                                    s.setBool(value.getAsBoolean());
                                    break;
                                case DOUBLE:
                                    s.setDouble(value.getAsDouble());
                                    break;
                                case MODE:
                                    s.setModeIndex(value.getAsInt());
                                    break;
                            }
                        }
                    }

                    // Apply enabled state last, after settings are loaded, so onEnable()
                    // sees the restored settings rather than module defaults.
                    if (mj.has("enabled") && mj.get("enabled").getAsBoolean()) {
                        module.setEnabled(true);
                    }
                }
            }

            if (root.has("hudPositions")) {
                for (Map.Entry<String, JsonElement> entry : root.getAsJsonObject("hudPositions").entrySet()) {
                    JsonArray pos = entry.getValue().getAsJsonArray();
                    hudPositions.put(entry.getKey(), new int[]{pos.get(0).getAsInt(), pos.get(1).getAsInt()});
                }
            }
        } catch (Exception e) {
            System.err.println("[TZARR] Failed to load config, using defaults: " + e.getMessage());
        }
    }
}
