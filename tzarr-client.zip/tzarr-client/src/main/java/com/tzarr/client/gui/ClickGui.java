package com.tzarr.client.gui;

import com.tzarr.client.TzarrClient;
import com.tzarr.client.module.Category;
import com.tzarr.client.module.Module;
import com.tzarr.client.module.Setting;
import com.tzarr.client.theme.Theme;
import com.tzarr.client.util.RenderUtils;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;

import java.util.ArrayList;
import java.util.List;

/**
 * The main ClickGUI. Opened/closed with the configurable menu key (default
 * RSHIFT, changeable in TzarrClient). All layout is computed each frame from
 * a handful of ints below rather than cached Swing-style components, which
 * keeps this file simple and is cheap enough at ClickGUI scale (it only
 * renders while the menu is actually open).
 */
public class ClickGui extends GuiScreen {

    private static final int SIDEBAR_WIDTH = 120;
    private static final int SEARCH_HEIGHT = 22;
    private static final int ROW_HEIGHT = 20;
    private static final int PANEL_WIDTH = 190;

    private Category selectedCategory = Category.HUD;
    private GuiTextField searchField;

    private long openedAt;
    private static final long ANIM_MS = 180;

    // module name -> whether its settings panel is expanded
    private final List<String> expanded = new ArrayList<>();

    // active slider drag: setting reference, or null
    private Setting draggingSetting;

    @Override
    public void initGui() {
        openedAt = System.currentTimeMillis();
        searchField = new GuiTextField(0, fontRendererObj, 12, 8, SIDEBAR_WIDTH - 24, SEARCH_HEIGHT - 6);
        searchField.setMaxStringLength(32);
        searchField.setFocused(true);
    }

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private float openProgress() {
        long elapsed = System.currentTimeMillis() - openedAt;
        if (elapsed >= ANIM_MS) return 1F;
        float t = elapsed / (float) ANIM_MS;
        // ease-out cubic for a smooth, non-linear pop-in
        return 1F - (float) Math.pow(1 - t, 3);
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        float progress = openProgress();

        int baseX = 30;
        int baseY = 30;
        int totalHeight = height - 60;

        // Dim the world slightly behind the GUI.
        RenderUtils.drawRect(0, 0, width, height, 0x66000000);

        // ---- Sidebar (category tabs + search) ----
        int sidebarHeight = (int) (totalHeight * progress);
        RenderUtils.drawRoundedRect(baseX, baseY, SIDEBAR_WIDTH, sidebarHeight, 6F, Theme.PANEL_BG);

        if (progress > 0.6F) {
            searchField.xPosition = baseX + 10;
            searchField.yPosition = baseY + 8;
            searchField.width = SIDEBAR_WIDTH - 20;
            searchField.drawTextBox();

            int tabY = baseY + SEARCH_HEIGHT + 14;
            for (Category cat : Category.values()) {
                boolean selected = cat == selectedCategory;
                boolean hovered = mouseX >= baseX + 6 && mouseX <= baseX + SIDEBAR_WIDTH - 6
                        && mouseY >= tabY && mouseY <= tabY + ROW_HEIGHT;

                int bg = selected ? Theme.ACCENT & 0x33FFFFFF | 0x22000000 : hovered ? Theme.PANEL_BG_HOVER : 0x00000000;
                if (selected || hovered) {
                    RenderUtils.drawRoundedRect(baseX + 6, tabY, SIDEBAR_WIDTH - 12, ROW_HEIGHT - 2, 4F, bg);
                }
                int textColor = selected ? Theme.ACCENT : Theme.TEXT_PRIMARY;
                fontRendererObj.drawStringWithShadow(cat.getDisplayName(), baseX + 14, tabY + 6, textColor);
                tabY += ROW_HEIGHT;
            }

            // HUD editor button, pinned to the bottom of the sidebar.
            int editorY = baseY + sidebarHeight - ROW_HEIGHT - 6;
            boolean editorHovered = mouseX >= baseX + 6 && mouseX <= baseX + SIDEBAR_WIDTH - 6
                    && mouseY >= editorY && mouseY <= editorY + ROW_HEIGHT - 2;
            RenderUtils.drawRoundedRect(baseX + 6, editorY, SIDEBAR_WIDTH - 12, ROW_HEIGHT - 2, 4F,
                    editorHovered ? Theme.PANEL_BG_HOVER : Theme.TOGGLE_OFF);
            fontRendererObj.drawStringWithShadow("HUD Editor", baseX + 14, editorY + 6, Theme.TEXT_SECONDARY);
        }

        // ---- Module panel for the selected category ----
        if (progress > 0.3F) {
            int panelX = baseX + SIDEBAR_WIDTH + 14;
            List<Module> modules = filteredModules();

            int panelHeight = (int) (totalHeight * progress);
            RenderUtils.drawGlow(panelX, baseY, PANEL_WIDTH, panelHeight, 6F, Theme.ACCENT, 0.10F);
            RenderUtils.drawRoundedRect(panelX, baseY, PANEL_WIDTH, panelHeight, 6F, Theme.PANEL_BG);

            fontRendererObj.drawStringWithShadow(selectedCategory.getDisplayName().toUpperCase(),
                    panelX + 12, baseY + 10, Theme.TEXT_SECONDARY);

            int rowY = baseY + 28;
            for (Module m : modules) {
                if (rowY > baseY + panelHeight - ROW_HEIGHT) break; // simple clip, no scroll in v1

                boolean hovered = mouseX >= panelX + 8 && mouseX <= panelX + PANEL_WIDTH - 8
                        && mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT;
                int rowBg = hovered ? Theme.PANEL_BG_HOVER : 0x00000000;
                if (hovered) RenderUtils.drawRoundedRect(panelX + 6, rowY, PANEL_WIDTH - 12, ROW_HEIGHT - 2, 4F, rowBg);

                int nameColor = m.isEnabled() ? Theme.TEXT_PRIMARY : Theme.TEXT_SECONDARY;
                fontRendererObj.drawStringWithShadow(m.getName(), panelX + 14, rowY + 6, nameColor);

                drawToggleSwitch(panelX + PANEL_WIDTH - 34, rowY + 4, m.isEnabled());

                rowY += ROW_HEIGHT;

                if (expanded.contains(m.getName()) && !m.getSettings().isEmpty()) {
                    for (Setting s : m.getSettings()) {
                        rowY = drawSettingRow(panelX, rowY, s, mouseX, mouseY);
                    }
                    rowY += 4;
                }
            }
        }

        searchField.updateCursorCounter();
    }

    private int drawSettingRow(int panelX, int rowY, Setting s, int mouseX, int mouseY) {
        fontRendererObj.drawStringWithShadow(s.getName(), panelX + 20, rowY + 6, Theme.TEXT_SECONDARY);

        switch (s.getType()) {
            case BOOLEAN: {
                drawToggleSwitch(panelX + PANEL_WIDTH - 34, rowY + 4, s.getBool());
                break;
            }
            case DOUBLE: {
                int barX = panelX + 20;
                int barY = rowY + 16;
                int barWidth = PANEL_WIDTH - 40;
                RenderUtils.drawRoundedRect(barX, barY, barWidth, 4, 2F, Theme.TOGGLE_OFF);
                float pct = (float) ((s.getDouble() - s.getMin()) / (s.getMax() - s.getMin()));
                RenderUtils.drawRoundedRect(barX, barY, barWidth * pct, 4, 2F, Theme.ACCENT);
                String val = String.format("%.2f", s.getDouble());
                fontRendererObj.drawStringWithShadow(val, panelX + PANEL_WIDTH - 34, rowY + 6, Theme.TEXT_PRIMARY);
                rowY += 12;
                break;
            }
            case MODE: {
                fontRendererObj.drawStringWithShadow(s.getMode(), panelX + PANEL_WIDTH - 60, rowY + 6, Theme.ACCENT);
                break;
            }
        }
        return rowY + ROW_HEIGHT;
    }

    private void drawToggleSwitch(int x, int y, boolean on) {
        int width = 26, height = 12;
        int bg = on ? Theme.ACCENT : Theme.TOGGLE_OFF;
        RenderUtils.drawRoundedRect(x, y, width, height, height / 2F, bg);
        int knobX = on ? x + width - height : x;
        RenderUtils.drawRoundedRect(knobX + 1, y + 1, height - 2, height - 2, (height - 2) / 2F, 0xFFFFFFFF);
    }

    private List<Module> filteredModules() {
        List<Module> result = new ArrayList<>();
        String query = searchField.getText().toLowerCase().trim();
        List<Module> all = query.isEmpty()
                ? TzarrClient.getInstance().getModuleManager().getModules(selectedCategory)
                : TzarrClient.getInstance().getModuleManager().getModules();

        for (Module m : all) {
            if (!query.isEmpty()) {
                if (m.getName().toLowerCase().contains(query) || m.getDescription().toLowerCase().contains(query)) {
                    result.add(m);
                }
            } else {
                result.add(m);
            }
        }
        return result;
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws java.io.IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        searchField.mouseClicked(mouseX, mouseY, mouseButton);

        int baseX = 30, baseY = 30;

        // category tabs
        if (mouseX >= baseX + 6 && mouseX <= baseX + SIDEBAR_WIDTH - 6) {
            int tabY = baseY + SEARCH_HEIGHT + 14;
            for (Category cat : Category.values()) {
                if (mouseY >= tabY && mouseY <= tabY + ROW_HEIGHT) {
                    selectedCategory = cat;
                    return;
                }
                tabY += ROW_HEIGHT;
            }

            int totalHeight = height - 60;
            int sidebarHeight = (int) (totalHeight * openProgress());
            int editorY = baseY + sidebarHeight - ROW_HEIGHT - 6;
            if (mouseY >= editorY && mouseY <= editorY + ROW_HEIGHT - 2) {
                mc.displayGuiScreen(new HudEditorGui());
                return;
            }
        }

        // module rows
        int panelX = baseX + SIDEBAR_WIDTH + 14;
        int rowY = baseY + 28;
        for (Module m : filteredModules()) {
            if (mouseX >= panelX + 6 && mouseX <= panelX + PANEL_WIDTH - 6 && mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT) {
                if (mouseX >= panelX + PANEL_WIDTH - 34) {
                    m.toggle();
                } else {
                    if (expanded.contains(m.getName())) {
                        expanded.remove(m.getName());
                    } else {
                        expanded.add(m.getName());
                    }
                }
                return;
            }
            rowY += ROW_HEIGHT;

            if (expanded.contains(m.getName())) {
                for (Setting s : m.getSettings()) {
                    if (mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT) {
                        handleSettingClick(s, mouseX, panelX);
                    }
                    if (s.getType() == Setting.Type.DOUBLE) rowY += 12;
                    rowY += ROW_HEIGHT;
                }
                rowY += 4;
            }
        }
    }

    private void handleSettingClick(Setting s, int mouseX, int panelX) {
        switch (s.getType()) {
            case BOOLEAN:
                if (mouseX >= panelX + PANEL_WIDTH - 34) s.toggleBool();
                break;
            case MODE:
                s.cycleMode();
                break;
            case DOUBLE:
                draggingSetting = s;
                break;
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (draggingSetting != null) {
            int panelX = 30 + SIDEBAR_WIDTH + 14 + 20;
            int barWidth = PANEL_WIDTH - 40;
            float pct = (mouseX - panelX) / (float) barWidth;
            pct = Math.max(0F, Math.min(1F, pct));
            double value = draggingSetting.getMin() + pct * (draggingSetting.getMax() - draggingSetting.getMin());
            draggingSetting.setDouble(value);
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        draggingSetting = null;
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws java.io.IOException {
        if (keyCode == 1) { // ESC
            mc.displayGuiScreen(null);
            return;
        }
        if (searchField.isFocused()) {
            searchField.textboxKeyTyped(typedChar, keyCode);
        }
    }

    @Override
    public void onGuiClosed() {
        TzarrClient.getInstance().getConfigManager().save();
    }
}
