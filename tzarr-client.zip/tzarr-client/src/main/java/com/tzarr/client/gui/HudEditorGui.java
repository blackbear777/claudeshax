package com.tzarr.client.gui;

import com.tzarr.client.TzarrClient;
import com.tzarr.client.hud.HudModule;
import com.tzarr.client.module.Module;
import com.tzarr.client.theme.Theme;
import com.tzarr.client.util.RenderUtils;
import net.minecraft.client.gui.GuiScreen;

import java.util.ArrayList;
import java.util.List;

/**
 * Drag-and-drop repositioning for every enabled HUD element. Each box shows
 * the element's last rendered size (tracked by HudModule.lastWidth/Height
 * while it draws normally) so dragging here lines up with what you'll
 * actually see in-game.
 */
public class HudEditorGui extends GuiScreen {

    private HudModule dragging;
    private int dragOffsetX;
    private int dragOffsetY;

    @Override
    public boolean doesGuiPauseGame() {
        return false;
    }

    private List<HudModule> hudModules() {
        List<HudModule> result = new ArrayList<>();
        for (Module m : TzarrClient.getInstance().getModuleManager().getModules()) {
            if (m instanceof HudModule && m.isEnabled()) {
                result.add((HudModule) m);
            }
        }
        return result;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        RenderUtils.drawRect(0, 0, width, height, 0x55000000);

        fontRendererObj.drawStringWithShadow("HUD Editor - drag elements, ESC to close", 10, 10, Theme.TEXT_PRIMARY);

        for (HudModule hud : hudModules()) {
            int w = Math.max(hud.getLastWidth(), 40);
            int h = Math.max(hud.getLastHeight(), 12);
            boolean hovered = mouseX >= hud.getX() && mouseX <= hud.getX() + w
                    && mouseY >= hud.getY() && mouseY <= hud.getY() + h;

            int color = hud == dragging ? (0x66000000 | Theme.ACCENT & 0xFFFFFF) : hovered ? Theme.PANEL_BG_HOVER : 0x33000000;
            RenderUtils.drawRoundedRect(hud.getX() - 2, hud.getY() - 2, w + 4, h + 4, 4F, color);
            fontRendererObj.drawStringWithShadow(hud.getName(), hud.getX(), hud.getY() - 12, Theme.ACCENT);
        }
    }

    @Override
    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws java.io.IOException {
        super.mouseClicked(mouseX, mouseY, mouseButton);
        if (mouseButton != 0) return;

        for (HudModule hud : hudModules()) {
            int w = Math.max(hud.getLastWidth(), 40);
            int h = Math.max(hud.getLastHeight(), 12);
            if (mouseX >= hud.getX() && mouseX <= hud.getX() + w && mouseY >= hud.getY() && mouseY <= hud.getY() + h) {
                dragging = hud;
                dragOffsetX = mouseX - hud.getX();
                dragOffsetY = mouseY - hud.getY();
                return;
            }
        }
    }

    @Override
    protected void mouseClickMove(int mouseX, int mouseY, int clickedMouseButton, long timeSinceLastClick) {
        if (dragging != null) {
            dragging.setPosition(mouseX - dragOffsetX, mouseY - dragOffsetY);
        }
    }

    @Override
    protected void mouseReleased(int mouseX, int mouseY, int state) {
        super.mouseReleased(mouseX, mouseY, state);
        dragging = null;
    }

    @Override
    protected void keyTyped(char typedChar, int keyCode) throws java.io.IOException {
        if (keyCode == 1) { // ESC
            TzarrClient.getInstance().getConfigManager().save();
            mc.displayGuiScreen(null);
        }
    }

    @Override
    public void onGuiClosed() {
        TzarrClient.getInstance().getConfigManager().save();
    }
}
