package com.tzarr.client.gui;

import com.tzarr.client.theme.Theme;
import com.tzarr.client.util.RenderUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;

import java.util.LinkedList;
import java.util.List;

/**
 * Small "Module Enabled/Disabled" toast popups in the top-right corner.
 * Purely additive rendering - if the list is empty (nothing recently
 * toggled) render() returns immediately and costs nothing.
 */
public class NotificationManager {

    private static final long LIFETIME_MS = 2200;
    private static final long FADE_MS = 300;

    private final Minecraft mc = Minecraft.getMinecraft();
    private final List<Notification> active = new LinkedList<>();
    private boolean enabled = true;

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void notify(String text) {
        if (!enabled) return;
        active.add(new Notification(text, System.currentTimeMillis()));
    }

    public void render() {
        if (active.isEmpty()) return;

        ScaledResolution sr = new ScaledResolution(mc);
        int screenWidth = sr.getScaledWidth();

        long now = System.currentTimeMillis();
        int y = 6;

        // Remove expired ones first so the list never grows unbounded.
        active.removeIf(n -> now - n.createdAt > LIFETIME_MS);

        for (Notification n : active) {
            long age = now - n.createdAt;
            float alpha;
            if (age < FADE_MS) {
                alpha = age / (float) FADE_MS;
            } else if (age > LIFETIME_MS - FADE_MS) {
                alpha = (LIFETIME_MS - age) / (float) FADE_MS;
            } else {
                alpha = 1F;
            }
            alpha = Math.max(0F, Math.min(1F, alpha));

            String text = n.text;
            int textWidth = mc.fontRendererObj.getStringWidth(text);
            int boxWidth = textWidth + 16;
            int boxHeight = 16;
            int x = screenWidth - boxWidth - 8;

            int bg = ((int) (alpha * 200) << 24) | (Theme.PANEL_BG & 0xFFFFFF);
            RenderUtils.drawRoundedRect(x, y, boxWidth, boxHeight, 4F, bg);

            int accent = ((int) (alpha * 255) << 24) | (Theme.ACCENT & 0xFFFFFF);
            RenderUtils.drawRoundedRect(x, y, 3, boxHeight, 1.5F, accent);

            int textColor = ((int) (alpha * 255) << 24) | 0xFFFFFF;
            mc.fontRendererObj.drawStringWithShadow(text, x + 10, y + 4, textColor);

            y += boxHeight + 4;
        }
    }

    private static class Notification {
        final String text;
        final long createdAt;

        Notification(String text, long createdAt) {
            this.text = text;
            this.createdAt = createdAt;
        }
    }
}
