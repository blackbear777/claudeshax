package com.tzarr.client.hud;

import com.tzarr.client.TzarrClient;
import com.tzarr.client.module.Category;
import com.tzarr.client.module.Module;
import com.tzarr.client.theme.Theme;
import com.tzarr.client.util.RenderUtils;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

/**
 * A Module that also draws something on screen. Position is persisted
 * through ConfigManager under the module's name so it survives restarts,
 * and can be dragged around in HudEditorGui.
 */
public abstract class HudModule extends Module {

    protected int x;
    protected int y;
    protected int lastWidth = 60;
    protected int lastHeight = 10;

    protected HudModule(String name, String description, int defaultX, int defaultY) {
        super(name, description, Category.HUD, org.lwjgl.input.Keyboard.KEY_NONE);
        int[] saved = TzarrClient.getInstance().getConfigManager().getHudPosition(name);
        if (saved != null) {
            this.x = saved[0];
            this.y = saved[1];
        } else {
            this.x = defaultX;
            this.y = defaultY;
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
        TzarrClient.getInstance().getConfigManager().setHudPosition(getName(), x, y);
    }

    public int getLastWidth() {
        return lastWidth;
    }

    public int getLastHeight() {
        return lastHeight;
    }

    /** Draws a themed background box behind a single line of text and returns its height. */
    protected void drawLine(String text) {
        int width = mc.fontRendererObj.getStringWidth(text) + 10;
        int height = 12;
        RenderUtils.drawRoundedRect(x, y, width, height, 3F, Theme.PANEL_BG);
        mc.fontRendererObj.drawStringWithShadow(text, x + 5, y + 2, Theme.TEXT_PRIMARY);
        lastWidth = width;
        lastHeight = height;
    }

    /** Implement to draw this element; called once per frame while enabled. */
    protected abstract void renderHud();

    @SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (event.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.gameSettings.showDebugInfo) return; // don't clash with the F3 screen
        renderHud();
    }
}
