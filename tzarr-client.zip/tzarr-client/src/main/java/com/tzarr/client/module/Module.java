package com.tzarr.client.module;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.List;

/**
 * Base class for every feature in the client. A Module is a self-contained
 * unit that knows its own name/category/keybind/settings and can be toggled.
 *
 * Subclasses that need to listen to Forge events should register/unregister
 * themselves with the event bus in onEnable()/onDisable() (see the HUD
 * modules for examples) rather than staying registered permanently - this
 * keeps disabled modules from doing any work at all, which matters for
 * performance in 1.8.9.
 */
public abstract class Module {

    protected final Minecraft mc = Minecraft.getMinecraft();

    private final String name;
    private final String description;
    private final Category category;
    private boolean enabled;
    private int keyBind; // LWJGL key code, Keyboard.KEY_NONE if unset
    private final List<Setting> settings = new ArrayList<>();

    protected Module(String name, String description, Category category, int defaultKey) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.keyBind = defaultKey;
        this.enabled = false;
    }

    /** Called the moment the module is toggled on. Register listeners here. */
    protected void onEnable() {
    }

    /** Called the moment the module is toggled off. Unregister listeners here. */
    protected void onDisable() {
    }

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (enabled) {
            MinecraftForge.EVENT_BUS.register(this);
            onEnable();
        } else {
            onDisable();
            MinecraftForge.EVENT_BUS.unregister(this);
        }
        com.tzarr.client.TzarrClient.getInstance()
                .getNotificationManager()
                .notify(name + (enabled ? " enabled" : " disabled"));
    }

    public boolean isEnabled() {
        return enabled;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Category getCategory() {
        return category;
    }

    public int getKeyBind() {
        return keyBind;
    }

    public void setKeyBind(int keyBind) {
        this.keyBind = keyBind;
    }

    public String getKeyName() {
        return keyBind == Keyboard.KEY_NONE ? "NONE" : Keyboard.getKeyName(keyBind);
    }

    protected void addSetting(Setting setting) {
        settings.add(setting);
    }

    public List<Setting> getSettings() {
        return settings;
    }

    public Setting getSetting(String name) {
        for (Setting s : settings) {
            if (s.getName().equalsIgnoreCase(name)) return s;
        }
        return null;
    }
}
