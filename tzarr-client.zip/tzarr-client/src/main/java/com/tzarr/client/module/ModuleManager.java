package com.tzarr.client.module;

import com.tzarr.client.module.modules.hud.ArmorStatusHUD;
import com.tzarr.client.module.modules.hud.BridgingPracticeHUD;
import com.tzarr.client.module.modules.hud.CPSCounterHUD;
import com.tzarr.client.module.modules.hud.CoordsHUD;
import com.tzarr.client.module.modules.hud.FPSCounterHUD;
import com.tzarr.client.module.modules.hud.KeystrokesHUD;
import com.tzarr.client.module.modules.hud.PingHUD;
import com.tzarr.client.module.modules.hud.PotionEffectsHUD;
import com.tzarr.client.module.modules.hud.SessionStatsHUD;
import com.tzarr.client.module.modules.hud.TargetHUD;
import com.tzarr.client.module.modules.misc.ToggleNotifications;
import com.tzarr.client.module.modules.player.AutoSprint;
import com.tzarr.client.module.modules.render.Ambience;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.InputEvent;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Holds every registered module and dispatches keybind presses to them.
 * Add new modules to the list built in the constructor - the ClickGUI and
 * config system both read from this list, so nothing else needs to change.
 */
public class ModuleManager {

    private final Minecraft mc = Minecraft.getMinecraft();
    private final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        // HUD category - all passive/informational, safe to leave on by default.
        register(new FPSCounterHUD());
        register(new CPSCounterHUD());
        register(new PingHUD());
        register(new CoordsHUD());
        register(new KeystrokesHUD());
        register(new ArmorStatusHUD());
        register(new PotionEffectsHUD());
        register(new TargetHUD());
        register(new SessionStatsHUD());
        register(new BridgingPracticeHUD());

        // Player / Render / Misc examples showing the pattern for other categories.
        register(new AutoSprint());
        register(new Ambience());
        register(new ToggleNotifications());

        // NOTE: no aim-assist / auto-aim module is registered here by design.
        // See README.md for why, and for the "Target HUD" module (info-only,
        // shows the entity you're looking at without touching your camera).
    }

    private void register(Module module) {
        modules.add(module);
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    public List<Module> getModules(Category category) {
        List<Module> result = new ArrayList<>();
        for (Module m : modules) {
            if (m.getCategory() == category) result.add(m);
        }
        return result;
    }

    public Module getModule(String name) {
        for (Module m : modules) {
            if (m.getName().equalsIgnoreCase(name)) return m;
        }
        return null;
    }

    /**
     * Global keybind listener. GuiScreen.isCtrlKeyDown()-style checks are
     * skipped on purpose to keep this cheap; it only runs once per keypress,
     * not per tick, so it has no measurable FPS impact.
     */
    @SubscribeEvent
    public void onKeyInput(InputEvent.KeyInputEvent event) {
        // Don't fire module keybinds while any screen (ClickGUI, chat, inventory, etc.) is open -
        // this stops typing in chat or the search bar from accidentally toggling modules.
        if (mc.currentScreen != null) return;

        int key = Keyboard.getEventKey();
        if (key == 0 || !Keyboard.getEventKeyState()) return;

        for (Module m : modules) {
            if (m.getKeyBind() != Keyboard.KEY_NONE && m.getKeyBind() == key) {
                m.toggle();
            }
        }
    }
}
