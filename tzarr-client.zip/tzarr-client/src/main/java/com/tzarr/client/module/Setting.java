package com.tzarr.client.module;

import java.util.List;

/**
 * A single configurable value belonging to a Module (e.g. "Range", "Smoothing").
 * The ClickGUI renders one of these per row depending on {@link Type}, and
 * ConfigManager serializes them by name.
 */
public class Setting {

    public enum Type {
        BOOLEAN,
        DOUBLE,
        MODE
    }

    private final String name;
    private final Type type;

    // BOOLEAN
    private boolean boolValue;

    // DOUBLE (slider)
    private double doubleValue;
    private double min;
    private double max;
    private double step;

    // MODE (cycles through a fixed list of strings)
    private List<String> modes;
    private int modeIndex;

    private Setting(String name, Type type) {
        this.name = name;
        this.type = type;
    }

    public static Setting bool(String name, boolean defaultValue) {
        Setting s = new Setting(name, Type.BOOLEAN);
        s.boolValue = defaultValue;
        return s;
    }

    public static Setting slider(String name, double defaultValue, double min, double max, double step) {
        Setting s = new Setting(name, Type.DOUBLE);
        s.doubleValue = defaultValue;
        s.min = min;
        s.max = max;
        s.step = step;
        return s;
    }

    public static Setting mode(String name, List<String> modes, int defaultIndex) {
        Setting s = new Setting(name, Type.MODE);
        s.modes = modes;
        s.modeIndex = defaultIndex;
        return s;
    }

    public String getName() {
        return name;
    }

    public Type getType() {
        return type;
    }

    public boolean getBool() {
        return boolValue;
    }

    public void setBool(boolean value) {
        this.boolValue = value;
    }

    public void toggleBool() {
        this.boolValue = !this.boolValue;
    }

    public double getDouble() {
        return doubleValue;
    }

    public void setDouble(double value) {
        this.doubleValue = Math.max(min, Math.min(max, value));
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public double getStep() {
        return step;
    }

    public List<String> getModes() {
        return modes;
    }

    public String getMode() {
        return modes.get(modeIndex);
    }

    public void cycleMode() {
        modeIndex = (modeIndex + 1) % modes.size();
    }

    public void setModeIndex(int index) {
        if (index >= 0 && index < modes.size()) {
            modeIndex = index;
        }
    }

    public int getModeIndex() {
        return modeIndex;
    }
}
