package com.tzarr.client.module.modules.hud;

import com.tzarr.client.hud.HudModule;
import com.tzarr.client.theme.Theme;
import com.tzarr.client.util.RenderUtils;
import net.minecraft.item.ItemStack;

public class ArmorStatusHUD extends HudModule {

    public ArmorStatusHUD() {
        super("Armor Status", "Shows equipped armor pieces and durability.", 6, 280);
        setEnabled(true);
    }

    @Override
    protected void renderHud() {
        if (mc.thePlayer == null) return;
        ItemStack[] armor = mc.thePlayer.inventory.armorInventory;

        int rowY = y;
        int width = 90;
        boolean any = false;

        for (int i = armor.length - 1; i >= 0; i--) {
            ItemStack stack = armor[i];
            if (stack == null) continue;
            any = true;

            String name = stack.getDisplayName();
            int max = stack.getMaxDamage();
            int dmg = stack.getItemDamage();
            float remaining = max > 0 ? 1F - (dmg / (float) max) : 1F;

            RenderUtils.drawRoundedRect(x, rowY, width, 12, 3F, Theme.PANEL_BG);
            int barColor = remaining > 0.5F ? 0xFF4CD97B : remaining > 0.2F ? 0xFFE0C341 : 0xFFE0524B;
            RenderUtils.drawRoundedRect(x, rowY, width * remaining, 12, 3F, barColor);
            mc.fontRendererObj.drawStringWithShadow(trim(name, 14), x + 4, rowY + 2, 0xFFFFFFFF);

            rowY += 14;
        }

        lastWidth = width;
        lastHeight = any ? rowY - y : 0;
    }

    private String trim(String s, int max) {
        return s.length() > max ? s.substring(0, max) + "…" : s;
    }
}
