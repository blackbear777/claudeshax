package com.tzarr.client.module.modules.hud;

import com.tzarr.client.TzarrClient;
import com.tzarr.client.hud.HudModule;
import com.tzarr.client.theme.Theme;
import com.tzarr.client.util.RenderUtils;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

/**
 * A HUD for practicing legitimate manual bridging - it only ever *reads*
 * game state and the player's own inputs. It never places a block, moves
 * the player, or presses a key on their behalf.
 *
 * Shown: whether the block you're looking at is within normal reach,
 * milliseconds since your last right-click placement (bridge timing
 * feedback), your current sneak state, and clicks-per-second.
 */
public class BridgingPracticeHUD extends HudModule {

    private static final double REACH_DISTANCE = 4.5;
    private long lastPlacementAt = -1;

    public BridgingPracticeHUD() {
        super("Bridging Practice", "Reach/timing/sneak readouts for manual bridge practice. Places no blocks itself.", 6, 520);
    }

    @SubscribeEvent
    public void onInteract(PlayerInteractEvent event) {
        if (mc.thePlayer == null || event.entityPlayer != mc.thePlayer) return;
        if (event.action == PlayerInteractEvent.Action.RIGHT_CLICK_BLOCK) {
            long now = System.currentTimeMillis();
            lastPlacementAt = now;
        }
    }

    @Override
    protected void renderHud() {
        if (mc.thePlayer == null) return;

        boolean reachable = false;
        if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
            double dx = mc.objectMouseOver.hitVec.xCoord - mc.thePlayer.posX;
            double dy = mc.objectMouseOver.hitVec.yCoord - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
            double dz = mc.objectMouseOver.hitVec.zCoord - mc.thePlayer.posZ;
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            reachable = dist <= REACH_DISTANCE;
        }

        String sinceLast = lastPlacementAt < 0 ? "--" : (System.currentTimeMillis() - lastPlacementAt) + "ms";
        int cps = TzarrClient.getInstance().getClickTracker().getRightCps();

        String[] lines = {
                "Reachable: " + (reachable ? "YES" : "NO"),
                "Since last place: " + sinceLast,
                "Sneaking: " + (mc.thePlayer.isSneaking() ? "YES" : "NO"),
                "Place CPS: " + cps
        };

        int rowY = y;
        int width = 140;
        for (String line : lines) {
            RenderUtils.drawRoundedRect(x, rowY, width, 12, 3F, Theme.PANEL_BG);
            int color = line.startsWith("Reachable") ? (reachable ? 0xFF4CD97B : 0xFFE0524B) : Theme.TEXT_PRIMARY;
            mc.fontRendererObj.drawStringWithShadow(line, x + 5, rowY + 2, color);
            rowY += 13;
        }

        lastWidth = width;
        lastHeight = rowY - y;
    }
}
