package com.tzarr.client.module.modules.hud;

import com.tzarr.client.TzarrClient;
import com.tzarr.client.hud.HudModule;

public class CPSCounterHUD extends HudModule {

    public CPSCounterHUD() {
        super("CPS Counter", "Shows left/right clicks per second.", 6, 20);
        setEnabled(true);
    }

    @Override
    protected void renderHud() {
        int left = TzarrClient.getInstance().getClickTracker().getLeftCps();
        int right = TzarrClient.getInstance().getClickTracker().getRightCps();
        drawLine("CPS: " + left + " / " + right);
    }
}
