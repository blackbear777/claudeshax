package com.tzarr.client.module.modules.hud;

import com.tzarr.client.hud.HudModule;

public class CoordsHUD extends HudModule {

    public CoordsHUD() {
        super("Coordinates", "Shows your current X/Y/Z position.", 6, 48);
        setEnabled(true);
    }

    @Override
    protected void renderHud() {
        if (mc.thePlayer == null) return;
        int x = (int) Math.floor(mc.thePlayer.posX);
        int y = (int) Math.floor(mc.thePlayer.posY);
        int z = (int) Math.floor(mc.thePlayer.posZ);
        drawLine("XYZ: " + x + " / " + y + " / " + z);
    }
}
