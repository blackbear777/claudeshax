package com.tzarr.client.module.modules.hud;

import com.tzarr.client.hud.HudModule;
import net.minecraft.client.Minecraft;

public class FPSCounterHUD extends HudModule {

    public FPSCounterHUD() {
        super("FPS Counter", "Shows current frames per second.", 6, 6);
        setEnabled(true);
    }

    @Override
    protected void renderHud() {
        drawLine("FPS: " + Minecraft.getDebugFPS());
    }
}
