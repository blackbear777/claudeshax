package com.tzarr.client.module.modules.hud;

import com.tzarr.client.hud.HudModule;
import com.tzarr.client.theme.Theme;
import com.tzarr.client.util.RenderUtils;
import org.lwjgl.input.Mouse;

public class KeystrokesHUD extends HudModule {

    private static final int KEY_SIZE = 18;
    private static final int GAP = 2;

    public KeystrokesHUD() {
        super("Keystrokes", "Shows WASD and mouse button states.", 6, 200);
        setEnabled(true);
    }

    @Override
    protected void renderHud() {
        if (mc.thePlayer == null) return;

        boolean w = mc.gameSettings.keyBindForward.isKeyDown();
        boolean a = mc.gameSettings.keyBindLeft.isKeyDown();
        boolean s = mc.gameSettings.keyBindBack.isKeyDown();
        boolean d = mc.gameSettings.keyBindRight.isKeyDown();
        boolean space = mc.gameSettings.keyBindJump.isKeyDown();
        boolean left = Mouse.isButtonDown(0);
        boolean right = Mouse.isButtonDown(1);

        int col = x + KEY_SIZE + GAP;

        drawKey(x + KEY_SIZE + GAP, y, "W", w);
        drawKey(x, y + KEY_SIZE + GAP, "A", a);
        drawKey(x + KEY_SIZE + GAP, y + KEY_SIZE + GAP, "S", s);
        drawKey(x + (KEY_SIZE + GAP) * 2, y + KEY_SIZE + GAP, "D", d);

        int barY = y + (KEY_SIZE + GAP) * 2;
        int barWidth = (KEY_SIZE + GAP) * 3 - GAP;
        RenderUtils.drawRoundedRect(x, barY, barWidth, 12, 3F, space ? Theme.ACCENT : Theme.TOGGLE_OFF);
        mc.fontRendererObj.drawStringWithShadow("SPACE", x + barWidth / 2 - 14, barY + 2, 0xFFFFFFFF);

        int clickY = barY + 16;
        RenderUtils.drawRoundedRect(x, clickY, barWidth / 2 - 1, 12, 3F, left ? Theme.ACCENT : Theme.TOGGLE_OFF);
        RenderUtils.drawRoundedRect(x + barWidth / 2 + 1, clickY, barWidth / 2 - 1, 12, 3F, right ? Theme.ACCENT : Theme.TOGGLE_OFF);

        lastWidth = barWidth;
        lastHeight = clickY + 12 - y;
    }

    private void drawKey(int kx, int ky, String label, boolean active) {
        RenderUtils.drawRoundedRect(kx, ky, KEY_SIZE, KEY_SIZE, 3F, active ? Theme.ACCENT : Theme.TOGGLE_OFF);
        int textWidth = mc.fontRendererObj.getStringWidth(label);
        mc.fontRendererObj.drawStringWithShadow(label, kx + (KEY_SIZE - textWidth) / 2, ky + 5, 0xFFFFFFFF);
    }
}
