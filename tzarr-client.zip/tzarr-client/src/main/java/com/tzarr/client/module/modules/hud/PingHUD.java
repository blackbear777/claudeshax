package com.tzarr.client.module.modules.hud;

import com.tzarr.client.hud.HudModule;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;

public class PingHUD extends HudModule {

    public PingHUD() {
        super("Ping", "Shows your connection latency to the server.", 6, 34);
        setEnabled(true);
    }

    @Override
    protected void renderHud() {
        if (mc.thePlayer == null || mc.thePlayer.sendQueue == null) return;

        NetHandlerPlayClient netHandler = mc.thePlayer.sendQueue;
        NetworkPlayerInfo info = netHandler.getPlayerInfo(mc.thePlayer.getUniqueID());
        int ping = info != null ? info.getResponseTime() : -1;

        drawLine("Ping: " + (ping >= 0 ? ping + "ms" : "N/A"));
    }
}
