package com.tzarr.client.module.modules.hud;

import com.tzarr.client.hud.HudModule;
import com.tzarr.client.theme.Theme;
import com.tzarr.client.util.RenderUtils;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.StatCollector;

import java.util.Collection;

public class PotionEffectsHUD extends HudModule {

    public PotionEffectsHUD() {
        super("Potion Effects", "Lists your active potion effects with time remaining.", 6, 340);
        setEnabled(true);
    }

    @Override
    protected void renderHud() {
        if (mc.thePlayer == null) return;
        Collection<PotionEffect> effects = mc.thePlayer.getActivePotionEffects();
        if (effects.isEmpty()) {
            lastHeight = 0;
            return;
        }

        int rowY = y;
        int width = 120;

        for (PotionEffect effect : effects) {
            String name = StatCollector.translateToLocal(effect.getEffectName());
            int amplifier = effect.getAmplifier() + 1;
            int seconds = effect.getDuration() / 20;
            String time = String.format("%d:%02d", seconds / 60, seconds % 60);

            RenderUtils.drawRoundedRect(x, rowY, width, 12, 3F, Theme.PANEL_BG);
            mc.fontRendererObj.drawStringWithShadow(name + " " + toRoman(amplifier), x + 4, rowY + 2, Theme.TEXT_PRIMARY);
            mc.fontRendererObj.drawStringWithShadow(time, x + width - mc.fontRendererObj.getStringWidth(time) - 4, rowY + 2, Theme.ACCENT);

            rowY += 14;
        }

        lastWidth = width;
        lastHeight = rowY - y;
    }

    private String toRoman(int n) {
        String[] romans = {"", "I", "II", "III", "IV", "V"};
        return n < romans.length ? romans[n] : String.valueOf(n);
    }
}
