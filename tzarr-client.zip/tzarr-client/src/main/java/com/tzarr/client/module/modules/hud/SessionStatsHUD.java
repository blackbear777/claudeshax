package com.tzarr.client.module.modules.hud;

import com.tzarr.client.TzarrClient;
import com.tzarr.client.hud.HudModule;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

public class SessionStatsHUD extends HudModule {

    private long sessionStart;
    private int deaths;
    private int timesHurt;
    private float damageTaken;
    private int peakCps;

    public SessionStatsHUD() {
        super("Session Stats", "Tracks playtime, deaths, hits taken and peak CPS this session.", 6, 460);
    }

    @Override
    protected void onEnable() {
        sessionStart = System.currentTimeMillis();
        deaths = 0;
        timesHurt = 0;
        damageTaken = 0F;
        peakCps = 0;
    }

    @SubscribeEvent
    public void onHurt(LivingHurtEvent event) {
        if (mc.thePlayer != null && event.entity == mc.thePlayer) {
            timesHurt++;
            damageTaken += event.ammount;
        }
    }

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        if (mc.thePlayer != null && event.entity == mc.thePlayer) {
            deaths++;
        }
    }

    @Override
    protected void renderHud() {
        int cps = Math.max(
                TzarrClient.getInstance().getClickTracker().getLeftCps(),
                TzarrClient.getInstance().getClickTracker().getRightCps());
        if (cps > peakCps) peakCps = cps;

        long elapsed = (System.currentTimeMillis() - sessionStart) / 1000;
        String time = String.format("%02d:%02d", elapsed / 60, elapsed % 60);

        drawMultiLine(new String[]{
                "Session: " + time,
                "Deaths: " + deaths,
                "Hits taken: " + timesHurt + " (" + (int) damageTaken + " dmg)",
                "Peak CPS: " + peakCps
        });
    }

    private void drawMultiLine(String[] lines) {
        int rowY = y;
        int width = 130;
        for (String line : lines) {
            com.tzarr.client.util.RenderUtils.drawRoundedRect(x, rowY, width, 12, 3F, com.tzarr.client.theme.Theme.PANEL_BG);
            mc.fontRendererObj.drawStringWithShadow(line, x + 5, rowY + 2, com.tzarr.client.theme.Theme.TEXT_PRIMARY);
            rowY += 13;
        }
        lastWidth = width;
        lastHeight = rowY - y;
    }
}
