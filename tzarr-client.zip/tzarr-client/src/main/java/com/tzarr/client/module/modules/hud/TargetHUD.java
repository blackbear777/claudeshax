package com.tzarr.client.module.modules.hud;

import com.tzarr.client.hud.HudModule;
import com.tzarr.client.theme.Theme;
import com.tzarr.client.util.RenderUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.MathHelper;

/**
 * Purely informational - reads whatever entity you're already looking at
 * (mc.pointedEntity, the same raytrace result the game itself uses for
 * attacking/interacting) and displays its name/health/distance. This does
 * not touch player rotation, movement, or attack timing in any way.
 */
public class TargetHUD extends HudModule {

    public TargetHUD() {
        super("Target HUD", "Shows name, health and distance of the entity you're looking at.", 6, 400);
        setEnabled(true);
    }

    @Override
    protected void renderHud() {
        if (mc.thePlayer == null || !(mc.pointedEntity instanceof EntityPlayer)) {
            lastHeight = 0;
            return;
        }

        EntityPlayer target = (EntityPlayer) mc.pointedEntity;
        float distance = mc.thePlayer.getDistanceToEntity(target);
        float health = target.getHealth();
        float maxHealth = target.getMaxHealth();

        int width = 130;
        RenderUtils.drawRoundedRect(x, y, width, 28, 4F, Theme.PANEL_BG);
        mc.fontRendererObj.drawStringWithShadow(target.getName(), x + 6, y + 4, Theme.TEXT_PRIMARY);

        int barWidth = width - 12;
        RenderUtils.drawRoundedRect(x + 6, y + 15, barWidth, 5, 2F, Theme.TOGGLE_OFF);
        float pct = MathHelper.clamp_float(health / maxHealth, 0F, 1F);
        int healthColor = pct > 0.5F ? 0xFF4CD97B : pct > 0.25F ? 0xFFE0C341 : 0xFFE0524B;
        RenderUtils.drawRoundedRect(x + 6, y + 15, barWidth * pct, 5, 2F, healthColor);

        String distText = String.format("%.1fm", distance);
        mc.fontRendererObj.drawStringWithShadow(distText, x + width - mc.fontRendererObj.getStringWidth(distText) - 6, y + 4, Theme.TEXT_SECONDARY);

        lastWidth = width;
        lastHeight = 28;
    }
}
