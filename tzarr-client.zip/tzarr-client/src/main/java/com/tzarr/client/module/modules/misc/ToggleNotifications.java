package com.tzarr.client.module.modules.misc;

import com.tzarr.client.TzarrClient;
import com.tzarr.client.module.Category;
import com.tzarr.client.module.Module;
import org.lwjgl.input.Keyboard;

/**
 * A meta-module: its own enabled state simply mirrors into the
 * NotificationManager's on/off flag. Toggling this module toggles whether
 * enabling/disabling *other* modules shows a toast.
 */
public class ToggleNotifications extends Module {

    public ToggleNotifications() {
        super("Notifications", "Shows a popup when a module is toggled.", Category.MISC, Keyboard.KEY_NONE);
        setEnabled(true); // matches NotificationManager's own default of "on"
    }

    @Override
    protected void onEnable() {
        TzarrClient.getInstance().getNotificationManager().setEnabled(true);
    }

    @Override
    protected void onDisable() {
        TzarrClient.getInstance().getNotificationManager().setEnabled(false);
    }
}
