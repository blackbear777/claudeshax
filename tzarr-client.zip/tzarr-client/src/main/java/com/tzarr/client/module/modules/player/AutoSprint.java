package com.tzarr.client.module.modules.player;

import com.tzarr.client.module.Category;
import com.tzarr.client.module.Module;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Keeps the player sprinting while moving forward with enough hunger,
 * exactly like double-tapping W would - purely a convenience toggle,
 * same mechanical effect a vanilla player can already achieve by hand.
 */
public class AutoSprint extends Module {

    public AutoSprint() {
        super("Auto Sprint", "Automatically sprints while moving forward.", Category.PLAYER, Keyboard.KEY_NONE);
    }

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.START || mc.thePlayer == null) return;
        if (mc.thePlayer.getFoodStats().getFoodLevel() <= 6) return; // matches vanilla sprint restriction

        if (mc.gameSettings.keyBindForward.isKeyDown() && !mc.thePlayer.isSneaking()) {
            mc.thePlayer.setSprinting(true);
        }
    }
}
