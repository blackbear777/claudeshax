package com.tzarr.client.module.modules.render;

import com.tzarr.client.module.Category;
import com.tzarr.client.module.Module;
import com.tzarr.client.module.Setting;
import com.tzarr.client.theme.Theme;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

/**
 * Purely cosmetic: slowly cycles the client's accent color when "Rainbow"
 * mode is on. Demonstrates the Render category / MODE + slider settings -
 * not a gameplay-affecting module.
 */
public class Ambience extends Module {

    private final Setting rainbow = Setting.bool("Rainbow Accent", false);
    private final Setting speed = Setting.slider("Speed", 1.0, 0.1, 5.0, 0.1);
    private float hue;

    public Ambience() {
        super("Ambience", "Cosmetic accent color cycling for the client UI.", Category.RENDER, Keyboard.KEY_NONE);
        addSetting(rainbow);
        addSetting(speed);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START || !rainbow.getBool()) return;
        hue += 0.002F * (float) speed.getDouble();
        if (hue > 1F) hue -= 1F;
        Theme.setAccent(java.awt.Color.HSBtoRGB(hue, 0.55F, 1F));
    }
}
