package com.tzarr.client.theme;

/**
 * Central color palette for the client. ACCENT is mutable (persisted via
 * ConfigManager) so the user can pick their own highlight color; everything
 * else stays fixed to keep the UI visually consistent.
 */
public class Theme {

    public static final int BACKGROUND = 0xE6111318;      // near-black, slightly translucent
    public static final int PANEL_BG = 0xE6181B22;
    public static final int PANEL_BG_HOVER = 0xE61F232C;
    public static final int BORDER = 0x33FFFFFF;
    public static final int TEXT_PRIMARY = 0xFFEDEDF2;
    public static final int TEXT_SECONDARY = 0xFF8A8D98;
    public static final int TOGGLE_OFF = 0x552A2D38;

    /** Default accent (soft cyan). Overwritten on load if the config has a saved value. */
    public static int ACCENT = 0xFF4FD1E5;

    public static void setAccent(int rgb) {
        ACCENT = 0xFF000000 | (rgb & 0xFFFFFF);
    }
}
