package com.tzarr.client.util;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Tracks left/right clicks-per-second by edge-detecting the mouse button
 * state once per client tick (20/sec) rather than polling every render
 * frame. Registered once, permanently, in TzarrClient - the per-tick cost
 * is two boolean checks and, on an actual click, one deque add, so it has
 * no measurable effect on FPS even though it "always runs".
 */
public class ClickTracker {

    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean lastLeft;
    private boolean lastRight;
    private long lastLeftClickAt;
    private long lastRightClickAt;
    private long lastIntervalMs = -1;

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;

        boolean left = Mouse.isButtonDown(0);
        boolean right = Mouse.isButtonDown(1);
        long now = System.currentTimeMillis();

        if (left && !lastLeft) {
            leftClicks.addLast(now);
            if (lastLeftClickAt != 0) lastIntervalMs = now - lastLeftClickAt;
            lastLeftClickAt = now;
        }
        if (right && !lastRight) {
            rightClicks.addLast(now);
            lastRightClickAt = now;
        }
        lastLeft = left;
        lastRight = right;

        purge(leftClicks, now);
        purge(rightClicks, now);
    }

    private void purge(Deque<Long> deque, long now) {
        while (!deque.isEmpty() && now - deque.peekFirst() > 1000) {
            deque.pollFirst();
        }
    }

    public int getLeftCps() {
        return leftClicks.size();
    }

    public int getRightCps() {
        return rightClicks.size();
    }

    /** Milliseconds between the two most recent left clicks, or -1 if not enough data yet. */
    public long getLastClickIntervalMs() {
        return lastIntervalMs;
    }

    public long getLastRightClickAt() {
        return lastRightClickAt;
    }
}
