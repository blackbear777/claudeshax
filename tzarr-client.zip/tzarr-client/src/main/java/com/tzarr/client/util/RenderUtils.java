package com.tzarr.client.util;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import org.lwjgl.opengl.GL11;

/**
 * Small rendering helper library used by the ClickGUI and HUD modules.
 *
 * 1.8.9's renderer has no built-in rounded-rect or blur primitive, so
 * "rounded panel" here is a real triangle-fan rounded rectangle (not a
 * texture trick), and "glow" is a cheap multi-pass falloff around it.
 * Both are built once per draw call with a plain Tessellator - no object
 * allocation happens per tick, only when something is actually rendered.
 */
public class RenderUtils {

    /** Standard flat rectangle, e.g. for the background behind text. */
    public static void drawRect(double x, double y, double width, double height, int color) {
        float a = (color >> 24 & 255) / 255F;
        float r = (color >> 16 & 255) / 255F;
        float g = (color >> 8 & 255) / 255F;
        float b = (color & 255) / 255F;

        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
        GlStateManager.color(r, g, b, a);

        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(GL11.GL_QUADS, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION);
        wr.pos(x, y + height, 0).endVertex();
        wr.pos(x + width, y + height, 0).endVertex();
        wr.pos(x + width, y, 0).endVertex();
        wr.pos(x, y, 0).endVertex();
        tessellator.draw();

        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    /**
     * A rounded rectangle built from a fan of triangles per corner.
     * segments=8 is enough to look smooth at typical GUI sizes without
     * costing anything noticeable - it's a few dozen vertices, drawn only
     * while the ClickGUI/HUD element is actually visible.
     */
    public static void drawRoundedRect(float x, float y, float width, float height, float radius, int color) {
        radius = Math.min(radius, Math.min(width, height) / 2F);
        float a = (color >> 24 & 255) / 255F;
        float r = (color >> 16 & 255) / 255F;
        float g = (color >> 8 & 255) / 255F;
        float b = (color & 255) / 255F;

        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA, 1, 0);
        GlStateManager.color(r, g, b, a);

        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();
        wr.begin(GL11.GL_POLYGON, net.minecraft.client.renderer.vertex.DefaultVertexFormats.POSITION);

        int segments = 8;
        // top-left corner sweep, top-right, bottom-right, bottom-left, closing the loop
        float[][] corners = {
                {x + radius, y + radius, 180, 270},
                {x + width - radius, y + radius, 270, 360},
                {x + width - radius, y + height - radius, 0, 90},
                {x + radius, y + height - radius, 90, 180}
        };

        for (float[] c : corners) {
            float cx = c[0], cy = c[1], startDeg = c[2], endDeg = c[3];
            for (int i = 0; i <= segments; i++) {
                double deg = Math.toRadians(startDeg + (endDeg - startDeg) * (i / (double) segments));
                wr.pos(cx + Math.cos(deg) * radius, cy + Math.sin(deg) * radius, 0).endVertex();
            }
        }

        tessellator.draw();
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }

    /**
     * Fakes a soft glow by drawing the same rounded rect several times with
     * shrinking alpha and growing radius. Cheap (default 4 passes) and only
     * ever runs while the ClickGUI is open, so it never touches in-game FPS.
     */
    public static void drawGlow(float x, float y, float width, float height, float radius, int rgb, float maxAlpha) {
        int passes = 4;
        for (int i = passes; i >= 1; i--) {
            float spread = i * 2F;
            int alpha = (int) (maxAlpha * 255 / (i * 2.2F));
            int color = (alpha << 24) | (rgb & 0xFFFFFF);
            drawRoundedRect(x - spread, y - spread, width + spread * 2, height + spread * 2, radius + spread, color);
        }
    }

    /** Linear interpolation used for smooth open/close and hover transitions. */
    public static double lerp(double from, double to, double factor) {
        return from + (to - from) * factor;
    }

    public static float lerp(float from, float to, float factor) {
        return from + (to - from) * factor;
    }
}
